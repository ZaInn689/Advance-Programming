﻿using hardwareSystem.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hardwareSystem
{
    public partial class SignUp: Form
    {
        HardWareProjectEntities3 db = new HardWareProjectEntities3();
        public SignUp()
        {
            InitializeComponent();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String email = textBox1.Text;
            String password = textBox2.Text;
            String role = "user";
            var user = db.users.FirstOrDefault(us => us.email == email);
            if(user == null)
            {
                user us = new user();
                us.email = email;
                us.password = password;
                us.role = role;
                db.users.Add(us);
                db.SaveChanges();
                MessageBox.Show("Reguster successfully");
                
            }
            else
            {
                MessageBox.Show("You have alrady an account");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login t = new Login();
            t.Show();
        }
    }
}

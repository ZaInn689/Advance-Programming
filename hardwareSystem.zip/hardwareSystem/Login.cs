﻿using hardwareSystem.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hardwareSystem
{
    public partial class Login: Form
    {
        HardWareProjectEntities3 db = new HardWareProjectEntities3();

        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String email = textBox1.Text;
            String password = textBox2.Text;
            var user = db.users.FirstOrDefault(us => us.email ==email && us.password==password);
            if(user!=null)
            {
                if(user.role == "user")
                {
                    Coustomer form = new Coustomer();
                    form.Show();
                    this.Hide();

                }
                else
                {
                    Admin ad = new Admin();
                    ad.Show();
                    this.Hide();
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignUp sign = new SignUp();
            sign.Show();
            this.Hide();

        }
    }
}

﻿using hardwareSystem.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hardwareSystem
{
    public partial class Coustomer: Form
    {
        HardWareProjectEntities3 db = new HardWareProjectEntities3();

        public Coustomer()
        {
            InitializeComponent();
        }

        private void Coustomer_Load(object sender, EventArgs e)
        {
            comboBoxData();
        }
        private void comboBoxData()
        {
            comboBox1.DataSource = db.categories.ToList();
            comboBox1.DisplayMember = "name";
            comboBox1.ValueMember= "id";
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Please select an item.");
                return;
            }

            var selectedItem = (item)comboBox2.SelectedItem;

            int quantity;
            if (!int.TryParse(textBox1.Text, out quantity) || quantity <= 0)
            {
                MessageBox.Show("Please enter a valid quantity.");
                return;
            }

            var user = db.items.FirstOrDefault(i => i.id == selectedItem.id);

            if (user == null)
            {
                MessageBox.Show("Item not found in database.");
                return;
            }

            MessageBox.Show("Available: " + user.quantity + ", Requested: " + quantity);

            if (user.quantity < quantity)
            {
                MessageBox.Show("We do not have this quantity");
            }
            else
            {
                user.quantity = user.quantity - quantity;
                db.SaveChanges();

                MessageBox.Show("Purchase successful.\nRemaining: " + user.quantity);
                textBox1.Clear();
                comboBox2.SelectedIndex = -1;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selected = (category)comboBox1.SelectedItem;
            var items = db.items.Where(it => it.categoryId == selected.id).ToList();
            comboBox2.DataSource = items;
            comboBox2.SelectedIndex = -1;
            comboBox2.DisplayMember = "name";
            comboBox2.ValueMember = "id";
            comboBox2.SelectedIndex = -1;
        }
    }
}

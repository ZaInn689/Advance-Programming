﻿using hardwareSystem.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Validation;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hardwareSystem
{
    public partial class Admin: Form
    {
        HardWareProjectEntities3 db = new HardWareProjectEntities3();
        int selected = -1;
        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            comboBoxData();
            gidViewData();



        }
        private void comboBoxData()
        {
            comboBox1.DataSource = db.categories.ToList();
            comboBox1.DisplayMember = "name";
            comboBox1.ValueMember = "id";
        }
        private void gidViewData()
        {
            dataGridView1.Rows.Clear();
            foreach(var item in db.items)
            {
                dataGridView1.Rows.Add(item.id, item.name, item.category, item.quantity, item.price, item.categoryId);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String name= textBox1.Text;
            var seledted = (category)comboBox1.SelectedItem;
            String category = seledted.name;
            int id = seledted.id;
             String  quantity = (textBox2.Text);
            int q = int.Parse(textBox2.Text);
            String price = textBox3.Text;
            item item = new item();
            item.name = name;
            item.category = category;
            item.quantity = q;
            item.price = price;
            item.categoryId = id;
            db.items.Add(item);
            try
            {
                db.SaveChanges();
                MessageBox.Show("data addedd successfully");
                gidViewData();
                clear();



            }
            catch(Exception ex)
            {
                MessageBox.Show("error:" + ex.Message);
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(selected == -1)
            {
                MessageBox.Show("please select the data");
                return;
            }
            var existingItem = db.items.FirstOrDefault(item => item.id == selected);
            if(existingItem ==null)
            {
                MessageBox.Show("Item not fouund");
                return;
            }
            existingItem.name = textBox1.Text;
            existingItem.quantity = int.Parse(textBox2.Text);
            existingItem.price = textBox3.Text;
            var seledted = (category)comboBox1.SelectedItem;
            String cat = seledted.name;
            int id = seledted.id;
            existingItem.category = cat;
            existingItem.categoryId = id;
            try
            {
                db.SaveChanges();
                MessageBox.Show("data updated successfully");
                gidViewData();
                clear();

            }catch(Exception ex)
            {
                MessageBox.Show("Error" + ex.Message);
            }


        }
        private void clear()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex>0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["item"].Value.ToString();
                textBox2.Text = row.Cells["quantity"].Value.ToString();
                textBox3.Text = row.Cells["price"].Value.ToString();
                comboBox1.SelectedItem = row.Cells["category"].Value.ToString();
                selected = int.Parse(row.Cells["id"].Value.ToString());



            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var existingItem = db.items.FirstOrDefault(item => item.id == selected);
            if (existingItem == null)
            {
                MessageBox.Show("Item not fouund");
                return;
            }
            db.items.Remove(existingItem);
            try
            {
                db.SaveChanges();
                MessageBox.Show("data deleted successfully");
                gidViewData();
                clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.Message);
            }




        }
    }
}
